import React from "react";

const faqs = [
  {
    question: "How can I book a trip with Skiva?",
    answer:
      "Just head over to our homepage, choose your destination, and follow the guided steps to plan and book your trip.",
  },
  {
    question: "Can I cancel or reschedule my trip?",
    answer:
      "Yes! You can easily manage your bookings from your profile dashboard. Flexible policies apply based on your package.",
  },
  {
    question: "Is 24/7 support available?",
    answer:
      "Absolutely. Our travel experts are available anytime, anywhere, to assist you throughout your journey.",
  },
  {
    question: "Are there any discounts for group travel?",
    answer:
      "Yes! We offer exclusive discounts for group bookings. Contact our support for customized group packages.",
  },
];

const Faq = () => {
  return (
    <div className="min-h-screen bg-gray-950 text-white py-20 px-6 md:px-20">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold text-center text-cyan-400 mb-12">
          Frequently Asked Questions
        </h1>

        <div className="space-y-8">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-gray-800 border border-cyan-500/20 rounded-xl p-6 shadow-lg hover:shadow-cyan-500/30 transition duration-300"
            >
              <h2 className="text-xl font-semibold text-cyan-300 mb-2">
                {faq.question}
              </h2>
              <p className="text-gray-300">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Faq;
