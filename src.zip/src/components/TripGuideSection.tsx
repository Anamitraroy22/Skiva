import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Star, MapPin, Calendar, DollarSign } from "lucide-react";

// Updated image imports based on your folder structure
import destination1Image from "@/assets/destinations/destination1.jpg"; // Bali
import destination2Image from "@/assets/destinations/destination2.jpg"; // Switzerland
import destination3Image from "@/assets/destinations/destination3.jpg"; // Tokyo
import destination4Image from "@/assets/destinations/destination4.jpg"; // Cairo
import destination5Image from "@/assets/destinations/destination5.jpg"; // Greece
import destination6Image from "@/assets/destinations/destination6.jpg"; // India
import destination7Image from "@/assets/destinations/destination7.jpg"; // Iceland

const TripGuideSection = () => {
    const [activeFilter, setActiveFilter] = useState("recommended");

    const trips = [
        {
            id: 1,
            title: "Bali Paradise",
            location: "Bali, Indonesia",
            rating: 4.9,
            reviews: 2847,
            price: "$1,299",
            duration: "7 days",
            category: ["recommended", "budget"],
            image: destination1Image,
            description: "Experience the magic of Bali with temple visits, rice terrace tours, and beach relaxation.",
            highlights: ["Temple Tours", "Rice Terraces", "Beach Resorts", "Cultural Immersion"]
        },
        {
            id: 2,
            title: "Swiss Alpine Adventure",
            location: "Swiss Alps, Switzerland",
            rating: 4.8,
            reviews: 1923,
            price: "$2,899",
            duration: "10 days",
            category: ["recommended", "adventure"],
            image: destination2Image,
            description: "Conquer the Swiss Alps with hiking, skiing, and breathtaking mountain views.",
            highlights: ["Mountain Hiking", "Luxury Chalets", "Scenic Railways", "Adventure Sports"]
        },
        {
            id: 3,
            title: "Tokyo Neon Nights",
            location: "Tokyo, Japan",
            rating: 4.7,
            reviews: 3156,
            price: "$1,899",
            duration: "8 days",
            category: ["recommended", "adventure"],
            image: destination3Image,
            description: "Dive into the future with Tokyo's cyberpunk culture, cuisine, and technology.",
            highlights: ["Tech Districts", "Anime Culture", "Fine Dining", "Night Life"]
        },
        {
            id: 4,
            title: "Cairo Ancient Wonders",
            location: "Cairo, Egypt",
            rating: 4.6,
            reviews: 1500,
            price: "$1,550",
            duration: "6 days",
            category: ["recommended", "cultural"], // Added 'cultural' as a new category, but also 'recommended'
            image: destination4Image,
            description: "Uncover the mysteries of ancient Egypt with tours of pyramids, sphinx, and historical museums.",
            highlights: ["Pyramids of Giza", "Nile River Cruise", "Egyptian Museum", "Khan el-Khalili Bazaar"]
        },
        {
            id: 5,
            title: "Greek Island Hopping",
            location: "Santorini, Greece",
            rating: 4.9,
            reviews: 2100,
            price: "$2,100",
            duration: "9 days",
            category: ["recommended", "beach"], // Added 'beach' as a new category, but also 'recommended'
            image: destination5Image,
            description: "Explore the stunning blue domes and crystal-clear waters of the Greek islands.",
            highlights: ["Santorini Sunsets", "Mykonos Beaches", "Ancient Ruins", "Mediterranean Cuisine"]
        },
        {
            id: 6,
            title: "India Golden Triangle",
            location: "Delhi, Agra, Jaipur, India",
            rating: 4.7,
            reviews: 1750,
            price: "$1,400",
            duration: "8 days",
            category: ["recommended", "cultural"],
            image: destination6Image,
            description: "A cultural journey through India's iconic cities, including the Taj Mahal.",
            highlights: ["Taj Mahal", "Red Fort", "Amber Fort", "Local Markets"]
        },
        {
            id: 7,
            title: "Iceland Northern Lights",
            location: "Reykjavik, Iceland",
            rating: 4.8,
            reviews: 1800,
            price: "$3,200",
            duration: "7 days",
            category: ["recommended", "adventure"],
            image: destination7Image,
            description: "Witness the spectacular Northern Lights and explore Iceland's unique landscapes.",
            highlights: ["Aurora Borealis", "Blue Lagoon", "Golden Circle", "Glacier Hiking"]
        }
    ];

    const filters = [
        { id: "recommended", label: "Recommended", icon: Star },
        { id: "adventure", label: "Adventure", icon: MapPin },
        { id: "budget", label: "Budget-Friendly", icon: DollarSign }
        // Note: New categories like "cultural" or "beach" are not added to filters
        // If you want to filter by these, you'll need to add them to the 'filters' array.
    ];

    const filteredTrips = trips.filter(trip =>
        trip.category.includes(activeFilter)
    );

    return (
        <section className="py-20 bg-background relative overflow-hidden">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16 animate-fade-in">
                    <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
                        Discover Your Next
                        <span className="bg-gradient-primary bg-clip-text text-transparent"> Adventure</span>
                    </h2>
                    <p className="text-xl text-foreground-muted max-w-3xl mx-auto">
                        From mystical temples to futuristic cities, explore destinations that will transform your perspective
                    </p>
                </div>

                {/* Filter Buttons */}
                <div className="flex flex-wrap justify-center gap-4 mb-12">
                    {filters.map((filter) => {
                        const IconComponent = filter.icon;
                        return (
                            <Button
                                key={filter.id}
                                variant={activeFilter === filter.id ? "default" : "glass"}
                                size="lg"
                                onClick={() => setActiveFilter(filter.id)}
                                className="transition-all duration-300"
                            >
                                <IconComponent className="w-4 h-4 mr-2" />
                                {filter.label}
                            </Button>
                        );
                    })}
                </div>

                {/* Trip Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {filteredTrips.map((trip, index) => (
                        <div
                            key={trip.id}
                            className="glass rounded-2xl overflow-hidden card-hover group"
                            style={{ animationDelay: `${index * 0.1}s` }}
                        >
                            {/* Image */}
                            <div className="relative h-64 overflow-hidden">
                                <img
                                    src={trip.image}
                                    alt={trip.title}
                                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                                <div className="absolute top-4 right-4">
                                    <Badge variant="secondary" className="bg-primary/90 text-primary-foreground">
                                        <Calendar className="w-3 h-3 mr-1" />
                                        {trip.duration}
                                    </Badge>
                                </div>
                            </div>

                            {/* Content */}
                            <div className="p-6">
                                <div className="flex items-center justify-between mb-3">
                                    <h3 className="text-xl font-bold text-foreground">{trip.title}</h3>
                                    <div className="text-2xl font-bold text-primary">{trip.price}</div>
                                </div>

                                <div className="flex items-center text-foreground-muted mb-3">
                                    <MapPin className="w-4 h-4 mr-2 text-primary" />
                                    {trip.location}
                                </div>

                                <div className="flex items-center mb-4">
                                    <div className="flex items-center mr-4">
                                        <Star className="w-4 h-4 text-primary fill-current mr-1" />
                                        <span className="text-foreground font-medium">{trip.rating}</span>
                                        <span className="text-foreground-muted ml-1">({trip.reviews})</span>
                                    </div>
                                </div>

                                <p className="text-foreground-muted mb-4 line-clamp-2">
                                    {trip.description}
                                </p>

                                {/* Highlights */}
                                <div className="flex flex-wrap gap-2 mb-6">
                                    {trip.highlights.slice(0, 3).map((highlight, idx) => (
                                        <Badge
                                            key={idx}
                                            variant="outline"
                                            className="text-xs border-primary/20 text-primary"
                                        >
                                            {highlight}
                                        </Badge>
                                    ))}
                                </div>

                                <Button variant="outline" size="lg" className="w-full group-hover:bg-primary group-hover:text-primary-foreground">
                                    <Calendar className="w-4 h-4 mr-2" />
                                    Plan Now
                                </Button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Background Glow Effects */}
            <div className="absolute top-1/4 left-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
            <div className="absolute bottom-1/4 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl"></div>
        </section>
    );
};

export default TripGuideSection;