import { Rocket, Globe, Heart, Star } from "lucide-react";

const AboutSection = () => {
    const milestones = [
        { year: "2020", title: "Founded", description: "Started with a dream to revolutionize travel" },
        { year: "2021", title: "Global Expansion", description: "Reached 50+ destinations worldwide" },
        { year: "2022", title: "AI Integration", description: "Launched AI-powered trip recommendations" },
        { year: "2023", title: "1M+ Travelers", description: "Served over 1 million happy explorers" },
        { year: "2024", title: "Future Vision", description: "Building the next generation of travel experiences" }
    ];

    const features = [
        {
            icon: <Globe className="w-8 h-8" />,
            title: "Global Network",
            description: "Access to 200+ destinations with local expert guides"
        },
        {
            icon: <Rocket className="w-8 h-8" />,
            title: "Future-Ready",
            description: "AI-powered recommendations for personalized adventures"
        },
        {
            icon: <Heart className="w-8 h-8" />,
            title: "Sustainable Travel",
            description: "Eco-friendly journeys that protect our planet"
        },
        {
            icon: <Star className="w-8 h-8" />,
            title: "Premium Experience",
            description: "Luxury accommodations and unique experiences"
        }
    ];

    return (
        <section className="py-20 bg-background-light relative overflow-hidden">
            <div className="container mx-auto px-6">
                <div className="text-center mb-16 animate-fade-in">
                    <h2 className="text-4xl md:text-5xl font-bold mb-6 text-foreground">
                        About Our <span className="bg-gradient-primary bg-clip-text text-transparent">Journey</span>
                    </h2>
                    <p className="text-xl text-foreground-muted max-w-3xl mx-auto leading-relaxed">
                        We connect explorers with unforgettable journeys, using cutting-edge technology
                        to create personalized adventures that inspire and transform lives.
                    </p>
                </div>

                {/* Feature Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
                    {features.map((feature, index) => (
                        <div
                            key={index}
                            className="glass p-6 rounded-2xl text-center card-hover group"
                            style={{ animationDelay: `${index * 0.1}s` }}
                        >
                            <div className="text-primary mb-4 group-hover:text-accent transition-colors duration-300 flex justify-center">
                                {feature.icon}
                            </div>
                            <h3 className="text-xl font-semibold mb-3 text-foreground">{feature.title}</h3>
                            <p className="text-foreground-muted">{feature.description}</p>
                        </div>
                    ))}
                </div>

                {/* Timeline */}
                <div className="max-w-4xl mx-auto">
                    <h3 className="text-3xl font-bold text-center mb-12 text-foreground">Our Story</h3>
                    <div className="relative">
                        {/* Timeline Line */}
                        <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-primary to-accent rounded-full"></div>

                        {milestones.map((milestone, index) => (
                            <div
                                key={index}
                                className={`relative flex items-center mb-12 ${
                                    index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                                }`}
                            >
                                <div className={`w-1/2 ${index % 2 === 0 ? 'pr-8 text-right' : 'pl-8 text-left'}`}>
                                    <div className="glass p-6 rounded-xl card-hover">
                                        <div className="text-2xl font-bold text-primary mb-2">{milestone.year}</div>
                                        <h4 className="text-xl font-semibold text-foreground mb-2">{milestone.title}</h4>
                                        <p className="text-foreground-muted">{milestone.description}</p>
                                    </div>
                                </div>

                                {/* Timeline Node */}
                                <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-primary rounded-full border-4 border-background-light shadow-lg animate-glow"></div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            {/* Background Elements */}
            <div className="absolute top-10 right-10 w-20 h-20 bg-primary/10 rounded-full blur-xl"></div>
            <div className="absolute bottom-20 left-10 w-32 h-32 bg-accent/10 rounded-full blur-xl"></div>
        </section>
    );
};

export default AboutSection;