import React from 'react';

const Footer = () => {
    return (
        <footer className="bg-gray-900 text-white py-10 px-4 mt-20">
            <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-10">
                {/* FAQ Section */}
                <div>
                    <h2 className="text-xl font-semibold mb-4">FAQs</h2>
                    <ul className="space-y-2 text-gray-300">
                        <li><strong>Q:</strong> How can I book a trip?</li>
                        <li><strong>A:</strong> Click on "Explore Trips" and choose your destination.</li>
                        <li><strong>Q:</strong> Is support available 24/7?</li>
                        <li><strong>A:</strong> Yes, our travel advisors are available around the clock.</li>
                        <li><strong>Q:</strong> Can I cancel or reschedule?</li>
                        <li><strong>A:</strong> Absolutely. Visit your profile to manage bookings.</li>
                    </ul>
                </div>

                {/* Developer Credit */}
                <div className="text-gray-400 text-sm">
                    <p>Made with ❤️ by <strong>Anamitra Roy</strong></p>
                    <p>&copy; {new Date().getFullYear()} Skiva. All rights reserved.</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
