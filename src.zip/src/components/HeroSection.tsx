import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CalendarDays, MapPin, Users, Search, Plane } from "lucide-react";
import heroImage from "@/assets/hero.jpg"; // Updated image import path

const HeroSection = () => {
    const [typewriterText, setTypewriterText] = useState("");
    const fullText = "Explore. Dream. Discover.";

    useEffect(() => {
        let currentIndex = 0;
        const timer = setInterval(() => {
            if (currentIndex <= fullText.length) {
                setTypewriterText(fullText.slice(0, currentIndex));
                currentIndex++;
            } else {
                clearInterval(timer);
            }
        }, 100);

        return () => clearInterval(timer);
    }, []);

    return (
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
            {/* Background Image with Overlay */}
            <div
                className="absolute inset-0 bg-cover bg-center bg-no-repeat"
                style={{ backgroundImage: `url(${heroImage})` }}
            >
                <div className="absolute inset-0 bg-gradient-hero opacity-80"></div>
            </div>

            {/* Hero Content */}
            <div className="relative z-10 container mx-auto px-6 text-center">
                <div className="max-w-4xl mx-auto animate-fade-in">
                    <h1 className="text-5xl md:text-7xl font-bold mb-6 text-foreground flex justify-center items-center gap-2">
                        <Plane className="w-10 h-10 text-primary animate-bounce-horizontal" />
                        Your Next Great
                        <span className="bg-gradient-primary bg-clip-text text-transparent block">
                            Adventure Starts Here
                        </span>
                    </h1>

                    <div className="text-xl md:text-2xl mb-8 text-foreground-muted h-8">
                        <span className="typewriter font-light">
                            {typewriterText}
                            {typewriterText.length < fullText.length && (
                                <span className="animate-blink-caret">|</span>
                            )}
                        </span>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                        <Button variant="hero" size="xl" className="animate-glow">
                            <MapPin className="w-5 h-5 mr-2" />
                            Explore Trips
                        </Button>
                        <Button variant="glass" size="xl">
                            <CalendarDays className="w-5 h-5 mr-2" />
                            Get Travel Guide
                        </Button>
                    </div>

                    {/* Floating Search Bar */}
                    <div className="glass max-w-4xl mx-auto p-6 rounded-2xl float animate-scale-in">
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div className="relative">
                                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                                <Input
                                    placeholder="Where to?"
                                    className="pl-10 bg-glass-bg/50 border-glass-border/30 text-foreground"
                                />
                            </div>

                            <div className="relative">
                                <CalendarDays className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                                <Input
                                    type="date"
                                    className="pl-10 bg-glass-bg/50 border-glass-border/30 text-foreground"
                                />
                            </div>

                            <div className="relative">
                                <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary w-4 h-4" />
                                <Input
                                    placeholder="Travelers"
                                    className="pl-10 bg-glass-bg/50 border-glass-border/30 text-foreground"
                                />
                            </div>

                            <Button variant="default" size="lg" className="w-full">
                                <Search className="w-4 h-4 mr-2" />
                                Search
                            </Button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Floating Elements */}
            <div className="absolute top-20 left-10 w-2 h-2 bg-primary rounded-full animate-float opacity-60"></div>
            <div className="absolute top-40 right-20 w-3 h-3 bg-accent rounded-full animate-float opacity-80" style={{ animationDelay: '1s' }}></div>
            <div className="absolute bottom-32 left-1/4 w-1 h-1 bg-primary-glow rounded-full animate-float opacity-70" style={{ animationDelay: '2s' }}></div>
        </section>
    );
};

export default HeroSection;
